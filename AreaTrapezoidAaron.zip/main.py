#this programm will ask the user the number of the dimensions of the trapezoide and then
# it will calculate the area of the trapezoid 
print("Today we will calculate  the area of a Trapezoid ")
base_1 = int(input( "what is the base 1(cm)?"))
base_2 = int(input("what is the  base 2 (cm)?"))
height = int(input("what is the  height (cm)?"))
sum_of_bases = base_1 + base_2
area = sum_of_bases * (height / 2)
print("the area of the Trapezoid " + str(height) + "cm with base 1  of" + str(base_1) 
      + "cm and base 2 of " + str(base_2) + "cm" + "is" + str(area) + "cm^2")